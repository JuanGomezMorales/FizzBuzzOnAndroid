package com.example.assigment5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

public class Login2 extends AppCompatActivity {

    public static final String EXTRA_MESSAGE = "com.example.android.assignment5.extra.MESSAGE";
    private EditText mUserName;
    private EditText mPassword;
    private static final String LOG_TAG = Login2.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(LOG_TAG, "Login2:onCreate:begin");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login2);
        mUserName = (EditText) findViewById(R.id.editTextPTwoU);
        mPassword = (EditText) findViewById(R.id.editTextPTwoP);
        Log.d(LOG_TAG, "Login2:onCreate:end");
    }

    public void login(View view) {
        Log.d(LOG_TAG, "Login2:login:begin");
        String name = mUserName.getText().toString();
        String pass = mPassword.getText().toString();
        Intent intentpass = getIntent();
        String key = name + pass + "|" + intentpass.getStringExtra(ViewUser.EXTRA_MESSAGE);
        Intent intent = new Intent(this, Game.class);
        intent.putExtra(EXTRA_MESSAGE, key);
        startActivity(intent);
        Log.d(LOG_TAG, "Login2:login:end");
        finish();
    }

    public void guest(View view) {
        Log.d(LOG_TAG, "Login2:guest:begin");
        Intent intent = new Intent(this, Game.class);
        intent.putExtra(EXTRA_MESSAGE, "GUEST");
        startActivity(intent);
        Log.d(LOG_TAG, "Login2:guest:end");
        finish();
    }
}