package com.example.assigment5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

public class ViewUser extends AppCompatActivity {

    public static final String EXTRA_MESSAGE = "com.example.android.assignment5.extra.MESSAGE";
    private static final String LOG_TAG = ViewUser.class.getSimpleName();
    private EditText mUserName;
    private EditText mPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(LOG_TAG, "ViewUser:start viewUser");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_user);
        mUserName = (EditText) findViewById(R.id.editTextUserNameV);
        mPassword = (EditText) findViewById(R.id.editTextPasswordV);

    }

    public void userViewDone(View view) {
        Log.d(LOG_TAG, "ViewUser:start button click");
        String name = mUserName.getText().toString();
        String pass = mPassword.getText().toString();
        String key = name + pass;
        Intent intent = new Intent(this, DisplayUser.class);
        intent.putExtra(EXTRA_MESSAGE, key);
        Log.d(LOG_TAG, "ViewUser:launch display");
        startActivity(intent);
        Log.d(LOG_TAG, "ViewUser:done");
        finish();
    }
}