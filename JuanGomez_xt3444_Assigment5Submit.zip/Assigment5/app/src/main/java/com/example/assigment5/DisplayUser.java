package com.example.assigment5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

public class DisplayUser extends AppCompatActivity {

    private String key;
    private SharedPreferences mPreferences;
    private String sharedPrefFile =
            "com.example.android.assignment5sharedpreferences";
    private static final String LOG_TAG = DisplayUser.class.getSimpleName();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(LOG_TAG, "DisplayUser:start display");
        super.onCreate(savedInstanceState);
        mPreferences = getSharedPreferences(sharedPrefFile, MODE_PRIVATE);
        setContentView(R.layout.activity_display_user);
        Intent intent = getIntent();
        key = intent.getStringExtra(ViewUser.EXTRA_MESSAGE);
        Log.d(LOG_TAG, "DisplayUser:get preferences");
        Log.d(LOG_TAG, "DisplayUser:key:" + key);
        Log.d(LOG_TAG, "DisplayUser:display name");
        TextView name = (TextView) findViewById(R.id.userNameDisplay);
        String username = mPreferences.getString(key + "u", "DEFAULT");
        if (name != null) {
            Log.d(LOG_TAG, "DisplayUser:name displayed");
            name.setText("Username: " + username);
        }

        Log.d(LOG_TAG, "DisplayUser:display wins");
        TextView wins = (TextView) findViewById(R.id.displayWins);
        int win = mPreferences.getInt(key + "w", 0);
        if (wins != null) {
            Log.d(LOG_TAG, "DisplayUser:wins displayed");
            wins.setText("Wins: " + Integer.toString(win));
        }

        Log.d(LOG_TAG, "DisplayUser:display highscore");
        TextView highscore = (TextView) findViewById(R.id.displayHighscore);
        int highscor = mPreferences.getInt(key + "h", 0);
        if (highscore != null) {
            Log.d(LOG_TAG, "DisplayUser:highscore displayed");
            highscore.setText("Highscore: " + Integer.toString(highscor));
        }

        Log.d(LOG_TAG, "DisplayUser:display fizzes");
        TextView fizz = (TextView) findViewById(R.id.displayFizz);
        int f = mPreferences.getInt(key + "f", 0);
        if (fizz != null) {
            Log.d(LOG_TAG, "DisplayUser:fizzes displayed");
            fizz.setText("Fizzes: " + Integer.toString(f));
        }

        Log.d(LOG_TAG, "DisplayUser:display buzzes");
        TextView buzz = (TextView) findViewById(R.id.displayBuzz);
        int b = mPreferences.getInt(key + "b", 0);
        if (buzz != null) {
            Log.d(LOG_TAG, "DisplayUser:buzzes displayed");
            buzz.setText("Buzzes: " + Integer.toString(b));
        }

        Log.d(LOG_TAG, "DisplayUser:display fizzbuzzes");
        TextView fb = (TextView) findViewById(R.id.displayFizzbuzz);
        int fibi = mPreferences.getInt(key + "d", 0);
        if (fb != null) {
            Log.d(LOG_TAG, "DisplayUser:fizzbuzzes displayed");
            fb.setText("Fizzbuzzes: " + Integer.toString(fibi));
        }
    }

    public void finished(View view) {
        finish();
    }
}