package com.example.assigment5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

public class AddUser extends AppCompatActivity {

    private EditText mUserName;
    private EditText mPassword;
    private static final String LOG_TAG = AddUser.class.getSimpleName();
    private SharedPreferences mPreferences;
    private String sharedPrefFile =
            "com.example.android.assignment5sharedpreferences";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(LOG_TAG, "AddUser:start addUser");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_user);
        mPreferences = getSharedPreferences(sharedPrefFile, MODE_PRIVATE);
        mUserName = (EditText) findViewById(R.id.editTextUsername);
        mPassword = (EditText) findViewById(R.id.editTextPassword);
    }

    public void userCreateDone(View view) {
        Log.d(LOG_TAG, "AddUser:start creating user");
        String name = mUserName.getText().toString();
        String pass = mPassword.getText().toString();
        String key = name + pass;
        SharedPreferences.Editor preferencesEditor = mPreferences.edit();
        //username
        preferencesEditor.putString(key + "u", name);
        //wins
        preferencesEditor.putInt(key + "w", 0);
        //highscore
        preferencesEditor.putInt(key + "h", 0);
        //fizzes
        preferencesEditor.putInt(key + "f", 0);
        //buzzes
        preferencesEditor.putInt(key + "b", 0);
        //fizzbuzzes
        preferencesEditor.putInt(key + "d", 0);
        preferencesEditor.apply();
        Log.d(LOG_TAG, "AddUser:done creating user");
        finish();
    }
}