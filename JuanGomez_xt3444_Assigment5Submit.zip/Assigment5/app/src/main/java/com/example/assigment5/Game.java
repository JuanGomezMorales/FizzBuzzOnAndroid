package com.example.assigment5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

public class Game extends AppCompatActivity {

    public static final String EXTRA_MESSAGE = "com.example.android.assignment5.extra.MESSAGE";
    private TextView player1Count = null;
    private TextView player2Count = null;
    private int mCount = 1;
    boolean turn = false;
    private int pOb = 0;
    private int pOf = 0;
    private int pOfb = 0;
    private int pTb = 0;
    private int pTf = 0;
    private int pTfb = 0;
    private static final String LOG_TAG = AddUser.class.getSimpleName();
    private SharedPreferences mPreferences;
    private String sharedPrefFile =
            "com.example.android.assignment5sharedpreferences";
    private String key;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(LOG_TAG, "Game:onCreate:begin");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        mPreferences = getSharedPreferences(sharedPrefFile, MODE_PRIVATE);
        player1Count = (TextView) findViewById(R.id.countDisplay);
        player2Count = (TextView) findViewById(R.id.countViewPT);
        Intent intent = getIntent();
        key = intent.getStringExtra(ViewUser.EXTRA_MESSAGE);
        Log.d(LOG_TAG, "Game:onCreate:begin");
    }

    public void playerOFizz(View view) {
        if(!turn)
        {
            if((mCount % 3 == 0) && !(mCount % 5 == 0))
            {
                mCount++;
                player1Count.setText(String.valueOf(mCount));
                player2Count.setText(String.valueOf(mCount));
                player1Count.setVisibility(View.INVISIBLE);
                player2Count.setVisibility(View.VISIBLE);
                turn = true;
                pOf++;
            }
            else
            {
                endGame();
            }
        }
    }

    public void playerOCount(View view) {
        if(!turn)
        {
            if(!(mCount % 3 == 0) && !(mCount % 5 == 0))
            {
                mCount++;
                player1Count.setText(String.valueOf(mCount));
                player2Count.setText(String.valueOf(mCount));
                player1Count.setVisibility(View.INVISIBLE);
                player2Count.setVisibility(View.VISIBLE);
                turn = true;
            }
            else
            {
                endGame();
            }
        }
    }

    public void playerOBuzz(View view) {
        if(!turn)
        {
            if(!(mCount % 3 == 0) && (mCount % 5 == 0))
            {
                mCount++;
                player1Count.setText(String.valueOf(mCount));
                player2Count.setText(String.valueOf(mCount));
                player1Count.setVisibility(View.INVISIBLE);
                player2Count.setVisibility(View.VISIBLE);
                turn = true;
                pOb++;
            }
            else
            {
                endGame();
            }
        }
    }

    public void playerOfizzbuzz(View view) {
        if(!turn)
        {
            if((mCount % 3 == 0) && (mCount % 5 == 0))
            {
                mCount++;
                player1Count.setText(String.valueOf(mCount));
                player2Count.setText(String.valueOf(mCount));
                player1Count.setVisibility(View.INVISIBLE);
                player2Count.setVisibility(View.VISIBLE);
                turn = true;
                pOfb++;
            }
            else
            {
                endGame();
            }
        }
    }

    public void playerTfizzbuzz(View view) {
        if(turn)
        {
            if((mCount % 3 == 0) && (mCount % 5 == 0))
            {
                mCount++;
                player1Count.setText(String.valueOf(mCount));
                player2Count.setText(String.valueOf(mCount));
                player1Count.setVisibility(View.VISIBLE);
                player2Count.setVisibility(View.INVISIBLE);
                turn = false;
                pTfb++;
            }
            else
            {
                endGame();
            }
        }
    }

    public void playerTCount(View view) {
        if(turn)
        {
            if(!(mCount % 3 == 0) && !(mCount % 5 == 0))
            {
                mCount++;
                player1Count.setText(String.valueOf(mCount));
                player2Count.setText(String.valueOf(mCount));
                player1Count.setVisibility(View.VISIBLE);
                player2Count.setVisibility(View.INVISIBLE);
                turn = false;
            }
            else
            {
                endGame();
            }
        }
    }

    public void playerTBuzz(View view) {
        if(turn)
        {
            if(!(mCount % 3 == 0) && (mCount % 5 == 0))
            {
                mCount++;
                player1Count.setText(String.valueOf(mCount));
                player2Count.setText(String.valueOf(mCount));
                player1Count.setVisibility(View.VISIBLE);
                player2Count.setVisibility(View.INVISIBLE);
                turn = false;
                pTb++;
            }
            else
            {
                endGame();
            }
        }
    }

    public void playerTFizz(View view) {
        if(turn)
        {
            if((mCount % 3 == 0) && !(mCount % 5 == 0))
            {
                mCount++;
                player1Count.setText(String.valueOf(mCount));
                player2Count.setText(String.valueOf(mCount));
                player1Count.setVisibility(View.VISIBLE);
                player2Count.setVisibility(View.INVISIBLE);
                turn = false;
                pTf++;
            }
            else
            {
                endGame();
            }
        }
    }

    public void endGame()
    {
        SharedPreferences.Editor preferencesEditor = mPreferences.edit();

        //get keys
        String userOkey = "";
        String userTkey = "";
        int i;
        if(key.equals("GUEST"))
        {
            userOkey = "GUEST";
            userTkey = "GUEST";
        }
        else
        {
            for(i = 0; key.charAt(i) != '|' && i < key.length(); i++)
            {
                userTkey += key.charAt(i);
            }
            for(i = i + 1; i < key.length(); i++)
            {
                userOkey += key.charAt(i);
            }
        }


        //add wins
        if(turn)
            preferencesEditor.putInt(userOkey + "w", mPreferences.getInt(userOkey + "w", 0) + 1);
        else
            preferencesEditor.putInt(userTkey + "w", mPreferences.getInt(userTkey + "w", 0) + 1);

        //add fizzes
        preferencesEditor.putInt(userOkey + "f", mPreferences.getInt(userOkey + "f", 0) + pOf);
        preferencesEditor.putInt(userTkey + "f", mPreferences.getInt(userTkey + "f", 0) + pTf);

        //add buzzes
        preferencesEditor.putInt(userOkey + "b", mPreferences.getInt(userOkey + "b", 0) + pOb);
        preferencesEditor.putInt(userTkey + "b", mPreferences.getInt(userTkey + "b", 0) + pTb);

        //add fizzbuzzes
        preferencesEditor.putInt(userOkey + "d", mPreferences.getInt(userOkey + "d", 0) + pOfb);
        preferencesEditor.putInt(userTkey + "d", mPreferences.getInt(userTkey + "d", 0) + pTfb);

        //update highscore
        if(turn)
        {
            if(mPreferences.getInt(userOkey + "h", 0) < mCount - 1)
                preferencesEditor.putInt(userOkey + "h",  mCount - 1);
            if(mPreferences.getInt(userTkey + "h", 0) < mCount - 2)
                preferencesEditor.putInt(userTkey + "h",  mCount - 2);

        }
        else
        {
            if(mPreferences.getInt(userOkey + "h", 0) < mCount - 2)
                preferencesEditor.putInt(userOkey + "h",  mCount - 2);
            if(mPreferences.getInt(userTkey + "h", 0) < mCount - 1)
                preferencesEditor.putInt(userTkey + "h",  mCount - 1);
        }

        if(turn)
            key = "O" + key;
        else
            key = "T" + key;

        Intent intent = new Intent(this, GameOverScreen.class);
        intent.putExtra(EXTRA_MESSAGE, key);
        startActivity(intent);
        finish();
    }

}