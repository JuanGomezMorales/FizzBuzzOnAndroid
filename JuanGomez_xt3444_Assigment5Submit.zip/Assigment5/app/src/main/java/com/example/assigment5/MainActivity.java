package com.example.assigment5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    public static final String EXTRA_MESSAGE = "com.example.android.assignment5.extra.MESSAGE";
    private static final String LOG_TAG = MainActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(LOG_TAG, "Main:begin");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void startGame(View view) {
        Log.d(LOG_TAG, "Main:enter startGame");
        Intent intent = new Intent(this, GameLogin.class);
        startActivity(intent);
    }

    public void addUser(View view) {
        Log.d(LOG_TAG, "Main:enter addUser");
        Intent intent = new Intent(this, AddUser.class);
        startActivity(intent);
    }

    public void viewUser(View view) {
        Log.d(LOG_TAG, "Main:enter viewUser");
        Intent intent = new Intent(this, ViewUser.class);
        startActivity(intent);
    }
}