package com.example.assigment5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

public class GameLogin extends AppCompatActivity {

    public static final String EXTRA_MESSAGE = "com.example.android.assignment5.extra.MESSAGE";
    private EditText mUserName;
    private EditText mPassword;
    private static final String LOG_TAG = GameLogin.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(LOG_TAG, "GameLogin:onCreate:begin");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_login);
        mUserName = (EditText) findViewById(R.id.editTextPOneU);
        mPassword = (EditText) findViewById(R.id.editTextPOneP);
        Log.d(LOG_TAG, "GameLogin:onCreate:end");
    }

    public void login(View view) {
        Log.d(LOG_TAG, "GameLogin:login:begin");
        String name = mUserName.getText().toString();
        String pass = mPassword.getText().toString();
        String key = name + pass;
        Intent intent = new Intent(this, Login2.class);
        intent.putExtra(EXTRA_MESSAGE, key);
        startActivity(intent);
        Log.d(LOG_TAG, "GameLogin:login:end");
        finish();

    }

    public void guest(View view) {
        Log.d(LOG_TAG, "GameLogin:guest:begin");
        Intent intent = new Intent(this, Login2.class);
        intent.putExtra(EXTRA_MESSAGE, "GUEST");
        startActivity(intent);
        Log.d(LOG_TAG, "GameLogin:guest:end");
        finish();
    }
}