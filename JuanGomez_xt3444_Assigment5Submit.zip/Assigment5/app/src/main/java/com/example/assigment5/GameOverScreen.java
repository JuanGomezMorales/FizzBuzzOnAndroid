package com.example.assigment5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class GameOverScreen extends AppCompatActivity {

    private static final String LOG_TAG = AddUser.class.getSimpleName();
    private SharedPreferences mPreferences;
    private String sharedPrefFile =
            "com.example.android.assignment5sharedpreferences";
    private String key;
    private TextView player1C = null;
    private TextView player2C = null;
    private boolean pO = false;
    private boolean pT = false;
    private String playerOname = "";
    private String playerTname = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        key = intent.getStringExtra(ViewUser.EXTRA_MESSAGE);
        setContentView(R.layout.activity_game_over_screen);
        player1C = (TextView) findViewById(R.id.playerOcongrats);
        player2C = (TextView) findViewById(R.id.playerTcongrats);
        mPreferences = getSharedPreferences(sharedPrefFile, MODE_PRIVATE);
        if(!key.equals("OGUEST") && !key.equals("TGUEST"))
        {
            int i;
            for(i = 1; key.charAt(i) != '|'; i++)
            {
                playerTname += key.charAt(i);
            }
            for(i = i + 1; i < key.length(); i++)
            {
                playerOname += key.charAt(i);
            }
            if(key.charAt(0) == 'O')
            {
                player1C.setText("Congratulations " + mPreferences.getString(playerOname + "u", "DEFAULT"));
                player2C.setText("Unfortunate" + mPreferences.getString(playerTname + "u", "DEFAULT"));
            }
            else
            {
                player1C.setText("Unfortunate " + mPreferences.getString(playerOname + "u", "DEFAULT"));
                player2C.setText("Congratulations " + mPreferences.getString(playerTname + "u", "DEFAULT"));
            }
        }
        else
        {
            if(key.charAt(0) == 'O')
            {
                player1C.setText("Congratulations GUEST");
                player2C.setText("Unfortunate GUEST");
            }
            else
            {
                player1C.setText("Unfortunate GUEST");
                player2C.setText("Congratulations GUEST");
            }
        }

    }

    public void doneOne(View view) {
        if(pT)
            finish();
        else
            pO = true;
    }

    public void doneTwo(View view) {
        if(pO)
            finish();
        else
            pT = true;
    }
}